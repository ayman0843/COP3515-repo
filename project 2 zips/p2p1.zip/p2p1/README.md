# University Equipment Rental System (UERS)

COP 3515 – Advanced Program Design
Client Change Request: CCR-001 (Sprint: Week 1)

## What Changed in This Client Change Request

This is the first release of UERS (version 1.0). Changes made:

- Created a new Cargo project named `equipment_rental`.
- Added three hard-coded equipment records, each with an Equipment ID, Name, Category, and Availability.
- Added a formatted inventory report that prints a title, a version number, and the three equipment items.
- Availability is stored as a `bool` and displayed as "Yes" or "No".
- Added comments throughout `src/main.rs`.

## How to Build and Run

```
cargo build
cargo run
```

## Expected Output

```
------------------------------------------------
University Equipment Rental System
Version 1.0
------------------------------------------------
Equipment Inventory

ID: 1001
Name: Laptop
Category: Computer
Available: Yes

ID: 1002
Name: Camera
Category: Photography
Available: Yes

ID: 1003
Name: Projector
Category: Classroom
Available: No
```

## How I Tested the Application

| Test | Description | Expected Result | Actual Result | Pass/Fail |
|------|-------------|-----------------|---------------|-----------|
| Cargo Build | Ran `cargo build` | Project compiles successfully | Project complied | Pass |
| Cargo Run | Ran `cargo run` | Program executes successfully | Project successfully ran | Pass |
| Equipment Display | Compared the report to the three required records | Three equipment items displayed correctly | The items displayed | Pass |
| Boolean Display | Checked the Available line of each item | Availability shown as Yes/No | Avaliability does show | Pass |

## AI Assistance Used

I used Claude to generate the first draft of `src/main.rs` and to draft questions for the customer and a README template. I reviewed the code, built and ran it with Cargo myself, tested it, and I understand every line of the submitted code.